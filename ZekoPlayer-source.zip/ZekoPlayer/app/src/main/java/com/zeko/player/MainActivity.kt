package com.zeko.player

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class VideoItem(val uri: Uri, val name: String, val duration: Long)

class MainActivity : AppCompatActivity() {
    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private val videos = mutableListOf<VideoItem>()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) loadVideos() else showEmpty("نحتاج إذن الوصول للفيديوهات حتى نعرض مكتبتك.") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 20)
            setBackgroundColor(0xFF09090D.toInt())
        }
        val title = TextView(this).apply {
            text = "ZEKO PLAYER"
            textSize = 27f
            setTextColor(0xFFEDE9FE.toInt())
            letterSpacing = 0.12f
        }
        val subtitle = TextView(this).apply {
            text = "مكتبة الفيديو"
            textSize = 16f
            setTextColor(0xFFA78BFA.toInt())
            setPadding(0, 8, 0, 22)
        }
        empty = TextView(this).apply {
            text = "جارٍ تحميل الفيديوهات..."
            textSize = 15f
            setTextColor(0xFFB8B5C5.toInt())
            gravity = Gravity.CENTER
        }
        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = VideoAdapter(videos) { item ->
                startActivity(Intent(this@MainActivity, PlayerActivity::class.java).setData(item.uri))
            }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(empty, LinearLayout.LayoutParams(-1, 110))
        layout.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
        requestVideoPermission()
    }

    private fun requestVideoPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) loadVideos()
        else permissionLauncher.launch(permission)
    }

    private fun loadVideos() {
        videos.clear()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION)
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        contentResolver.query(collection, projection, null, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                videos.add(VideoItem(Uri.withAppendedPath(collection, id.toString()), cursor.getString(nameCol) ?: "Video", cursor.getLong(durationCol)))
            }
        }
        list.adapter?.notifyDataSetChanged()
        empty.visibility = if (videos.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        if (videos.isEmpty()) showEmpty("ما لقينا فيديوهات بالجهاز. أضف فيديو وارجع افتح التطبيق.")
    }

    private fun showEmpty(message: String) {
        empty.text = message
        empty.visibility = android.view.View.VISIBLE
    }
}

class VideoAdapter(
    private val items: List<VideoItem>,
    private val onClick: (VideoItem) -> Unit
) : RecyclerView.Adapter<VideoAdapter.Holder>() {
    class Holder(val text: TextView) : RecyclerView.ViewHolder(text)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val tv = TextView(parent.context).apply {
            setPadding(18, 20, 18, 20)
            textSize = 16f
            setTextColor(0xFFF4F1FF.toInt())
            setBackgroundColor(0xFF17151F.toInt())
        }
        return Holder(tv)
    }
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        val mins = item.duration / 60000
        holder.text.text = "▶   ${item.name}\n      ${mins} دقيقة"
        holder.text.setOnClickListener { onClick(item) }
    }
    override fun getItemCount() = items.size
}
